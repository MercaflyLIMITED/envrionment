/** TYPES **/
function Token(token, startOffset, endOffset, position) {
  this.token = token;
  this.start_offset = startOffset;
  this.end_offset = endOffset;
  this.position = position;
}
